------- COMP30027 A2 ETHAN HAWKINS ------

1) the following perquisite packages are required to run this solution:
	cpi
	imblearn
	sklearn
	numpy
	pandas
	os
you likely have all of these except cpi, but all can be installed via pip.

2) ALL code is contained in src folder. ALL results are contained in results folder. ALL data is contained in data folder.

3) To obtain all results from this program, simply run from main. this will generate all plots and all CSVs. 

3.2) you may want to run it in an IDE of your choosing. I built it in PyCharm.

4) the results directory contains all results currently, but will be safely overwritten should you run the program. 

